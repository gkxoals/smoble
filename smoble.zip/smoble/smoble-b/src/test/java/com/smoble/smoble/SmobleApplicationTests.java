package com.smoble.smoble;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmobleApplicationTests {

	@Test
	void contextLoads() {
	}

}
