package com.smoble.smoble.user.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String password;


    private String profile_image_url;

    private String bio;

    private String temperature_score;

    private LocalDateTime create_at;
    private LocalDateTime updated_at;



}
