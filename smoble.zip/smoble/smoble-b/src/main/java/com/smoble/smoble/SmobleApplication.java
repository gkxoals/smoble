package com.smoble.smoble;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmobleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmobleApplication.class, args);
	}

}
