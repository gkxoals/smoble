package com.smoble.smoble.post;

public class post {
}
