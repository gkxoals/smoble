package com.smoble.smoble.user.entity;

public class ScoreHistory {
}
