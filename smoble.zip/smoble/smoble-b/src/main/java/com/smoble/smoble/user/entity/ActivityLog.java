package com.smoble.smoble.user.entity;

public class ActivityLog {
}
