package com.smoble.smoble.Exception;

public class UserNotFoundException {
}
