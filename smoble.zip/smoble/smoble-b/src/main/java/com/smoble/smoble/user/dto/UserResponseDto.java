package com.smoble.smoble.user.dto;

public class UserResponseDto {
}
