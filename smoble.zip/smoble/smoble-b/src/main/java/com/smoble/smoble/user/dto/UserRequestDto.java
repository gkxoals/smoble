package com.smoble.smoble.user.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class UserRequestDto {

}