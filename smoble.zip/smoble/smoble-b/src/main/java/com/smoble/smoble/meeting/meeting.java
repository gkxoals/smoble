package com.smoble.smoble.meeting;

public class meeting {
}
