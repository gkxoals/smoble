package com.smoble.smoble.user.repository;

public interface StyleTagRepository {
}
